# TaskFlow To-Do List

A responsive, accessible to-do list website built from the supplied `buggy_todo_list.js` assignment.

## Features

- Add tasks using the button or Enter key
- Mark tasks complete or active
- Delete individual tasks
- Filter all, active, and completed tasks
- Clear all completed tasks
- Save tasks in browser `localStorage`
- Responsive layout for mobile, tablet, and desktop
- Keyboard focus indicators and screen-reader status announcements
- Reduced-motion support

## Project files

- `index.html` — page structure
- `style.css` — responsive styling
- `script.js` — task logic and event handlers

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Add a task to get started.

No build tools or dependencies are required. Google Fonts are optional; the page has fallback fonts.

## Publish with GitHub Pages

1. Create a new public GitHub repository named `todo-list-project`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site. The live URL will be shown in the Pages settings.

Typical URL format: `https://YOUR-USERNAME.github.io/todo-list-project/`

## Notes on the original buggy JavaScript

The supplied script had an off-by-one loop condition (`<=`), which accessed an index beyond the end of the array. It also used the clicked item's text to find its index, which could delete the wrong item when duplicate task names existed. The add-button listener could also run before the element existed.

This version fixes those issues by:
- Iterating over valid indexes only.
- Passing each task's array index directly to its event handler.
- Attaching event listeners after `DOMContentLoaded`.
- Trimming input and validating indexes before removal.

The original core function names `addItem()`, `updateList()`, and `removeItem()` are retained. The data is stored as task objects so completion state and unique task identity can be supported.
